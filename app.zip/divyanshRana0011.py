
import sys
import os
sys.stdout.flush()  # Ensures print statements appear immediately






from flask import Flask, request, jsonify
import pyodbc
import os  # Used for environment variables
from flask_cors import CORS  # Allows frontend integration (optional)

app = Flask(__name__)
CORS(app)  # Enables CORS (useful if you connect via frontend)

# Function to create a new database connection
def get_db_connection():
    try:
        # Fetch environment variables
        server = os.getenv("DATABASE_SERVER")
        database = os.getenv("DATABASE_NAME")
        username = os.getenv("DATABASE_USER")
        password = os.getenv("DATABASE_PASSWORD")

        # Debugging: Print credentials (except password)
        print("🔹 DATABASE_SERVER:", server)
        print("🔹 DATABASE_NAME:", database)
        print("🔹 DATABASE_USER:", username)

        # Ensure environment variables exist
        if not all([server, database, username, password]):
            print("❌ ERROR: One or more database environment variables are missing!")
            return None

        # Create database connection
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={server};"
            f"DATABASE={database};"
            f"UID={username};"
            f"PWD={password};"
            f"Encrypt=yes;"
            f"TrustServerCertificate=no;"
            f"Connection Timeout=30;"
        )
        print("✅ Database Connection Successful!")
        return conn
    except Exception as e:
        print("❌ Database Connection Failed:", str(e))
        return None

# ✅ Homepage Route
@app.route('/')
def home():
    return jsonify({"message": "Welcome to the Product Catalogue API! Use `/products` to interact."})

# ✅ Route to add a new product
@app.route('/products', methods=['POST'])
def add_product():
    conn = get_db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        data = request.json
        if not all(k in data for k in ("name", "description", "price")):
            return jsonify({"error": "Missing required fields"}), 400

        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Products (name, description, price) VALUES (?, ?, ?)",
            (data['name'], data['description'], data['price'])
        )
        conn.commit()
        return jsonify({"message": "Product added successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route('/products', methods=['GET'])
def list_products():
    print("🔄 /products route called")  # Debugging line
    conn = get_db_connection()
    if not conn:
        print("❌ Database connection failed!")
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, description, price FROM Products")
        rows = cursor.fetchall()

        # ✅ Fix: Convert Decimal to float
        products = [
            {"id": row[0], "name": row[1], "description": row[2], "price": float(row[3])}  # Convert Decimal to float
            for row in rows
        ]

        print("✅ JSON Response:", products)  # Debugging line
        return jsonify(products)
    except Exception as e:
        print("❌ Error in /products route:", str(e))
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    import os
    port = int(os.environ.get("PORT", 8000))  # Use 8000 for Azure
    app.run(host="0.0.0.0", port=port, debug=True)







